import { getAuth, GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { getStorage } from 'firebase/storage';
import { getFirestore } from 'firebase/firestore/lite';

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCwgR6WOEobAtraV9QPplLNw1FIQCDS5nc",
  authDomain: "react-portfolio-dashboar-c140a.firebaseapp.com",
  projectId: "react-portfolio-dashboar-c140a",
  storageBucket: "react-portfolio-dashboar-c140a.appspot.com",
  messagingSenderId: "844117017900",
  appId: "1:844117017900:web:a1c1c7ef2f7f51f84a1889"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Google authorization method 
export const auth = getAuth();
const provider = new GoogleAuthProvider();
export const db = getFirestore(app);
export const storage = getStorage(app);

export const signInWithGoogle = () => signInWithPopup(auth,provider);
import './index.scss';
import { useEffect, useRef } from 'react';
import LogoS from '../../assets/images/mephoto.png';

const Logo = () => {
    const bgRef = useRef();
    const solidLogoRef = useRef();

    useEffect(() => {
        // Logic that does not involve GSAP can be placed here, if needed
        bgRef.current.style.opacity = 1;
        solidLogoRef.current.style.opacity = 1;
    }, []);

    return (
        <div className="logo-container" ref={bgRef}>
            <img ref={solidLogoRef} className='solid-logo' src={LogoS} alt='logo' />
        </div>
    );
}

export default Logo;
